
package twitterguitheforth;

public class Post {
	
	public Post(String newContent, int newUserID, int timestamp){
		
		
	}
	
	public void setHashTags(String pullFrom){
//		String[] newhashtags = 
	}
	
	public void setAtTags(String pullFrom){
		
	}
	

	
	String content;
	int userID;
	String[] hashtags;
	String[] atTags;
	int timestamp;
	boolean pub;
	
}
