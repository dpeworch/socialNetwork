
package twitterguitheforth;

public class BinaryStringSearchTree {

	public BinaryStringSearchTree() {
		
	}
	
	public void addNode(String hash){
		
		if (exists(hash)){
			
		}
	}
	
	
	public boolean exists(String hash){
		boolean thing = true;
		return thing;
	}
	
	
	
	StringNode current;
	StringNode head;
	
}
