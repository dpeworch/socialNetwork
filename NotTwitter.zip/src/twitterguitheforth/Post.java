
package twitterguitheforth;


public class Post {
	
	/**
         * constructs an empty post
         */
	public Post(){
		content = "Post not found.";
		postID = -1;
	}
	
	/**
         * Constructs a post data.
         * 
         * @param newContent The stored content of the post
         * @param newUserID The user who wrote the post
         * @param time The time at which the post was written
         * @param htags Subject tags
         * @param aTags Reply tags
         * @param pID Generated post ID.
         * @param visibility Private/public boolean
         */
	public Post(String newContent, int newUserID, long time, String[] htags, String[] aTags, int pID, String visibility){
		content = newContent;
		userID = newUserID;
		timestamp = time;
		hashtags = htags;
		atTags = aTags;
		postID = pID;
		if(visibility.equals("pub")){
			pub = true;
		} else {
			pub = false;
		}
	}
	

	
	String content;
	int userID;
	String[] hashtags;
	String[] atTags;
	long timestamp;
	int postID;
	boolean pub;
	
}
